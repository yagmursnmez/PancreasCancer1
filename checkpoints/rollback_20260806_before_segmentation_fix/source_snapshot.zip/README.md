# PancreasCancerDetection

CT görüntülerinden pankreas tümörü tespiti — nnU-Net v2 2D Segmentasyon Pipeline

## Proje Yapısı

```
PancreasCancer/
├── data/
│   ├── raw/                         # Kaggle'dan indirilen orijinal NIfTI dosyaları
│   ├── nnunet_raw/                  # nnU-Net formatına çevrilmiş veriler
│   │   └── Dataset007_Pancreas/
│   │       ├── imagesTr/            # Eğitim CT'leri (case_XXXX_0000.nii.gz)
│   │       ├── labelsTr/            # Eğitim maskeleri (case_XXXX.nii.gz)
│   │       ├── imagesTs/            # Test CT'leri
│   │       └── dataset.json
│   ├── nnunet_preprocessed/         # nnU-Net ön işleme (otomatik)
│   ├── nnunet_results/              # Eğitilmiş model ağırlıkları
│   └── inference_output/            # Segmentasyon sonuçları
├── scripts/
│   ├── utils.py                     # Ortak yardımcı fonksiyonlar
│   ├── prepare_dataset.py           # ADIM 2: Veri hazırlama
│   ├── validate_metrics.py          # ADIM 5: Doğrulama metrikleri
│   ├── inference.py                 # ADIM 6-7: Inference + Classification
│   └── reconstruct_3d.py            # ADIM 8: 3D Rekonstrüksiyon
├── web/
│   ├── app.py                       # Flask web uygulaması
│   ├── templates/
│   └── static/
├── logs/
├── metrics/
├── notebooks/
├── setup_project.py                 # ADIM 1: Proje kurulumu
├── verify_step1.py                  # ADIM 1: Kurulum doğrulama
├── requirements.txt
├── setup.bat                        # Windows kurulum
├── setup.sh                         # Linux/Mac kurulum
└── config.json                      # Merkezi konfigürasyon
```

## Hızlı Başlangıç

### 1. Kurulum (Windows)
```batch
setup.bat
```

### 2. Sanal Ortamı Aktif Et
```powershell
.\venv\Scripts\activate
```

### 3. nnU-Net Ortam Değişkenleri (PowerShell)
```powershell
$env:nnUNet_raw          = "C:\...\data\nnunet_raw"
$env:nnUNet_preprocessed = "C:\...\data\nnunet_preprocessed"
$env:nnUNet_results      = "C:\...\data\nnunet_results"
```

### 4. Veriyi İndir
Kaggle'dan [MSD Task07 Pancreas](https://www.kaggle.com/datasets/andrewmvd/medical-segmentation-decathlon) veri setini `data/raw/` klasörüne indirin.

### 5. Adımları Çalıştır
```bash
python scripts/prepare_dataset.py        # ADIM 2
nnUNetv2_plan_and_preprocess -d 007 -c 2d  # ADIM 3
nnUNetv2_train 007 2d 0                  # ADIM 4
python scripts/validate_metrics.py       # ADIM 5
python scripts/inference.py              # ADIM 6-7
python web/app.py                        # ADIM 9
```

## Etiketler

| Değer | Anlamı |
|-------|--------|
| 0 | Arka plan (Background) |
| 1 | Pankreas |
| 2 | Tümör |

## Metrikler

**Segmentasyon:** Dice Score, IoU
**Sınıflandırma:** Accuracy, Precision, Recall, F1, ROC-AUC

## Notlar

- GPU belleği 8GB altındaysa `--batch_size 2` kullanın
- Sadece fold 0 ile eğitim yapılmaktadır
- 3D full resolution KULLANILMAMAKTADIR — sadece nnU-Net 2D
