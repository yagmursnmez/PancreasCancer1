@echo off
REM ============================================================
REM Pancreas Cancer Detection - Windows Kurulum Scripti
REM ============================================================

echo [1/6] Python sanal ortami olusturuluyor...
python -m venv venv
if errorlevel 1 goto :error

echo [2/6] Sanal ortam aktif ediliyor...
call venv\Scripts\activate.bat

echo [3/6] pip guncelleniyor...
python -m pip install --upgrade pip

echo [4/6] PyTorch kuruluyor (CUDA 11.8)...
REM !! BU SATIRI DEGISTIR: CUDA surumunuze gore degistirin !!
REM CUDA 11.8 icin:
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118
REM CUDA 12.1 icin (yorumu kaldir):
REM pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
REM CPU icin (GPU yoksa):
REM pip install torch torchvision

echo [5/6] Diger gereksinimler kuruluyor...
pip install -r requirements.txt

echo [6/6] nnU-Net ortam degiskenleri ayarlaniyor...
REM !! BU SATIRI DEGISTIR: Kendi proje yolunuzu girin !!
setx nnUNet_raw      "%~dp0data\nnunet_raw"
setx nnUNet_preprocessed "%~dp0data\nnunet_preprocessed"
setx nnUNet_results  "%~dp0data\nnunet_results"

echo.
echo ============================================================
echo KURULUM TAMAMLANDI!
echo ============================================================
echo Ortam aktif etmek icin: venv\Scripts\activate
echo Kurulumu dogrulamak icin: python setup_project.py
echo.
goto :end

:error
echo HATA! Kurulum basarisiz.
exit /b 1

:end
pause
