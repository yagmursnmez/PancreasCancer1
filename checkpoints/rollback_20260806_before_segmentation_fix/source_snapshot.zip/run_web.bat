@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

title PancreasAI Web Servisi
set "OLD_PID="
for /f "tokens=5" %%P in ('netstat -ano ^| findstr /R /C:":5000 .*LISTENING"') do (
    if not defined OLD_PID set "OLD_PID=%%P"
)

if defined OLD_PID (
    echo [BILGI] 5000 portundaki eski servis kapatiliyor. PID=!OLD_PID!
    taskkill /PID !OLD_PID! /T /F >nul 2>&1
    timeout /t 1 /nobreak >nul
    tasklist /FI "PID eq !OLD_PID!" /NH 2>nul | findstr /I "python.exe" >nul
    if not errorlevel 1 (
        echo [HATA] Eski servis kapatilamadi.
        echo Eski terminali kapatin veya bu dosyayi Yonetici olarak calistirin.
        pause
        exit /b 1
    )
)

set "PYTHON_EXE=python"
if exist "%~dp0venv\Scripts\python.exe" set "PYTHON_EXE=%~dp0venv\Scripts\python.exe"

echo ============================================================
echo  PancreasAI guncel web servisi baslatiliyor
echo  URL: http://localhost:5000
echo  Yukleme siniri: .env dosyasindaki MAX_UPLOAD_MB
echo  Durdurmak icin: Ctrl+C
echo ============================================================
"%PYTHON_EXE%" web\app.py

if errorlevel 1 (
    echo.
    echo [HATA] Web servisi baslatilamadi.
    pause
)

endlocal
