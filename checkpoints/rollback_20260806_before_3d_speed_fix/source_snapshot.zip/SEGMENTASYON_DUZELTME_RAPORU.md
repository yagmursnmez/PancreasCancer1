# Segmentasyon Düzeltme Raporu — 2026-08-06

## Son durum

Üretim web hattı artık üç aşamalıdır:

1. **nnU-Net v2 2D:** pankreas ve tümör adayı üretir.
2. **MONAI DiNTS 3D:** bağımsız hacimsel pankreas ve tümör adayı üretir.
3. **TotalSegmentator 3D full:** pankreasın anatomik konumunu bağımsız olarak doğrular.

2B ve 3B tümör adayları birleştirildikten sonra son maskeye ancak şu koşullarla girer:

- 3B pankreas kapısı 3–250 mL ve en az 3 kesit olmalı.
- Pankreas modelleri arası Dice en az 0,20 olmalı.
- Her tümör bileşeni en az 0,30 mL ve en az 2 kesit olmalı.
- Bileşen pankreasın 30 mm anatomik bandına tutunmalı.
- Anatomik model çalışmazsa veya pankreası doğrulayamazsa ham maske yayımlanmaz; sonuç **karar verilemedi** olur.

## Düzeltilen ana hatalar

- DICOM hacmi eskiden kalıcı olarak `[-125, 225]` aralığına kırpılıyordu. Artık özgün HU korunuyor; yalnızca FOV dolgu/metal uçları `[-1024, 3071]` aralığına sınırlandırılıyor.
- Eski NIfTI affine hasta yönelimi ve konumunu yok sayıyordu. Artık DICOM IOP/IPP/PixelSpacing kullanılarak LPS→RAS affine, qform ve sform yazılıyor.
- Toraks/boyun serileri pankreas modeline gidebiliyordu. Negatif puanlı abdomen-dışı seriler artık reddediliyor; en az 16 dosya ve 10 gerçek uzamsal kesit aranıyor.
- `tumor_voxels > 50` tek başına tümör kararı veriyordu. Bu kural kaldırıldı.
- Voksel oranından uydurulan “% doğruluk/güven” kaldırıldı.
- Rastgele simülasyon maskesi geri dönüşleri kaldırıldı; başarısızlıkta sistem kapalı kalıyor.
- Boş tahmin klasöründe etiketi kendisiyle karşılaştırıp Dice=1,00 üreten doğrulama geri dönüşü kaldırıldı.
- Tek GPU’daki eşzamanlı web istekleri model kilidiyle sıraya alındı.

## Ölçümler

### Gerçek nnU-Net fold-0 doğrulaması — 46 vaka

- Pankreas Dice: **0,7698**
- Tümör Dice: **0,3104**
- Tümör tespiti: **34/46**

Rapor: `metrics/validation_report_20260806_121041.json`

`metrics/validation_report_20260729_120712.json` geçersizdir; etiketi kendisiyle karşılaştıran eski geri dönüş nedeniyle Dice=1,00 göstermiştir.

### Seçilmiş 8 pozitif fold-0 vakasında üç-model denetimi

- 2B nnU-Net tümör Dice ortalaması: **0,5897**
- Bellek-dostu 3B DiNTS tümör Dice ortalaması: **0,7634**
- Anatomik olarak doğrulanmış ensemble tümör Dice ortalaması: **0,8537**
- Doğrulanmış tümör adayı korunan vaka: **8/8**

Bu örneklem pozitif vakalardan seçildiği için negatif özgüllük ölçümü değildir.

Rapor: `metrics/tumor_ensemble_audit_20260806.json`

### PATIENT975891 uçtan uca sonuç

- Seçilen DICOM: 157 kesitlik portal-venöz abdomen serisi
- Spacing: 0,8079 × 0,8079 × 3,0 mm
- 3B model uyum Dice: **0,8097**
- Son pankreas hacmi: **74,498 mL**
- nnU-Net ham tümör: **1.230 voksel**
- DiNTS ham tümör: **0 voksel**
- Reddedilen ham tümör: **1.230 / 1.230 voksel**
- Son doğrulanmış tümör hacmi: **0,0 mL**
- Sonuç: **Doğrulanmış tümör adayı saptanmadı**
- Toplam süre: **342,55 saniye**

Son görsel: `web/static/results/PATIENT975891_ultra_seg.png`

### Negatif kontrol

Eski `denemetumorsuz` maskesinde **136.998** yanlış pankreas vokseli vardı. Bağımsız 3B kapı 0 pankreas vokseli üretti; yeni filtre son maskeyi tamamen boşalttı ve sonucu **karar verilemedi** yaptı.

## Tıbbi sınırlar

- Bu yazılım klinik karar verme veya kesin tanı aracı değildir.
- “Doğrulanmış tümör adayı saptanmadı” ifadesi kanseri dışlamaz.
- MSD Task07 eğitim/doğrulama verileri pankreas tümörlü portal-venöz CT’lerden oluşur; sağlıklı negatif kohort yoktur. Bu nedenle gerçek negatif özgüllük, farklı cihaz/faz ve dış-merkez performansı ayrıca uzman etiketli veriyle ölçülmelidir.
- Kusursuz/hatasız çalışma garanti edilemez. Sistem belirsiz durumda pozitif/negatif uydurmak yerine karar vermemek üzere tasarlanmıştır.

## Geri dönüş

Başlangıç geri dönüş noktası:

`checkpoints/rollback_20260806_before_segmentation_fix/GERI_DONUS_NOKTASI.md`

Kaynak arşivi SHA-256:

`BBC1F2B2957658012B41E840903C95666FFF0F993B90C68533283B32FF20CAC6`

