import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

import numpy as np


BASE_PATH = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE_PATH / "scripts"))
sys.path.insert(0, str(BASE_PATH / "web"))

from segmentation_postprocess import validate_and_fuse_segmentation
from app import _build_dicom_nifti_affine, _score_dicom_series


class SegmentationSafetyTests(unittest.TestCase):
    def setUp(self):
        self.shape = (48, 48, 48)
        self.spacing = (1.0, 1.0, 1.0)
        self.gate = np.zeros(self.shape, dtype=np.uint8)
        self.gate[12:34, 12:34, 12:34] = 1

    def test_empty_gate_fails_closed(self):
        raw = self.gate.copy()
        raw[18:28, 18:28, 18:22] = 2
        final, qc = validate_and_fuse_segmentation(
            raw, np.zeros_like(self.gate), self.spacing
        )
        self.assertFalse(np.any(final))
        self.assertIsNone(qc["has_tumor"])
        self.assertFalse(qc["pancreas_verified"])

    def test_supported_multislice_tumor_is_kept(self):
        raw = self.gate.copy()
        raw[18:28, 18:28, 18:22] = 2  # 0.4 mL, dört kesit
        final, qc = validate_and_fuse_segmentation(raw, self.gate, self.spacing)
        self.assertTrue(qc["pancreas_verified"])
        self.assertTrue(qc["has_tumor"])
        self.assertEqual(qc["tumor_voxels"], 400)
        self.assertEqual(int(np.count_nonzero(final == 2)), 400)

    def test_single_slice_tumor_is_rejected(self):
        raw = self.gate.copy()
        raw[13:33, 13:33, 20] = 2  # 0.4 mL fakat tek kesit
        final, qc = validate_and_fuse_segmentation(raw, self.gate, self.spacing)
        self.assertFalse(qc["has_tumor"])
        self.assertEqual(qc["tumor_voxels"], 0)
        self.assertIn("kesit_esigi", qc["tumor_components"][0]["rejection_reasons"])
        self.assertFalse(np.any(final == 2))

    def test_distant_tumor_is_rejected(self):
        raw = self.gate.copy()
        raw[0:10, 0:10, 0:5] = 2  # 0.5 mL, pankreastan uzak
        _, qc = validate_and_fuse_segmentation(
            raw, self.gate, self.spacing,
            {"tumor_support_radius_mm": 5.0, "min_tumor_support_fraction": 0.01},
        )
        self.assertFalse(qc["has_tumor"])
        self.assertEqual(qc["rejected_tumor_voxels"], 500)
        self.assertIn(
            "pankreas_komsulugu",
            qc["tumor_components"][0]["rejection_reasons"],
        )

    def test_low_cross_model_agreement_is_indeterminate(self):
        raw = np.zeros(self.shape, dtype=np.uint8)
        raw[0:8, 0:8, 0:8] = 1
        final, qc = validate_and_fuse_segmentation(raw, self.gate, self.spacing)
        self.assertIsNone(qc["has_tumor"])
        self.assertFalse(qc["pancreas_verified"])
        self.assertTrue(np.any(final == 1))
        self.assertFalse(np.any(final == 2))


class DicomGeometryTests(unittest.TestCase):
    def test_affine_maps_dicom_lps_to_nifti_ras(self):
        header = SimpleNamespace(
            ImageOrientationPatient=[1, 0, 0, 0, 1, 0],
            ImagePositionPatient=[-211.685, -378.916, -1488.144],
            PixelSpacing=[0.807890625, 0.807890625],
        )
        affine = _build_dicom_nifti_affine(header, [0, 0, 1], 3.0)
        expected = np.array([
            [0, -0.807890625, 0, 211.685],
            [-0.807890625, 0, 0, 378.916],
            [0, 0, 3.0, -1488.144],
            [0, 0, 0, 1],
        ])
        np.testing.assert_allclose(affine, expected)

    def test_thorax_series_receives_negative_score(self):
        header = SimpleNamespace(
            Modality="CT",
            SOPClassUID="1.2.840.10008.5.1.4.1.1.2",
            SeriesDescription="TORAKS AKCIGER",
            BodyPartExamined="CHEST",
            ImageType=["ORIGINAL", "PRIMARY", "AXIAL"],
            ConvolutionKernel="B70",
            SliceThickness=3.0,
            ContrastBolusAgent="",
            ImageOrientationPatient=[1, 0, 0, 0, 1, 0],
            ImagePositionPatient=[0, 0, 0],
        )
        headers = [
            (Path(f"slice_{index}.dcm"), SimpleNamespace(**{
                **header.__dict__, "ImagePositionPatient": [0, 0, index * 3]
            }), 512, 512)
            for index in range(50)
        ]
        score, _ = _score_dicom_series(headers)
        self.assertLess(score, 0)


if __name__ == "__main__":
    unittest.main()
