"""
============================================================
ADIM 9: WEB UYGULAMASI — Flask
============================================================
Kullanım:
    python web/app.py
    Tarayıcı: http://localhost:5000
============================================================
"""

import os
import sys
import json
import time
import uuid
import shutil
import subprocess
import gc
import logging
import tempfile
import threading
import unicodedata
from pathlib import Path
from datetime import datetime

from flask import (
    Flask, Request as FlaskRequest, render_template, request, redirect,
    url_for, flash, jsonify, send_from_directory
)
from werkzeug.utils import secure_filename
from werkzeug.exceptions import RequestEntityTooLarge

# ============================================================
# PATH AYARLARI
# ⚠️ BU SATIRI DEĞİŞTİR
# ============================================================
BASE_PATH  = Path(__file__).parent.parent
UPLOAD_DIR = BASE_PATH / "web" / "static" / "uploads"
RESULT_DIR = BASE_PATH / "web" / "static" / "results"
MASK_DIR   = BASE_PATH / "data" / "inference_output" / "segmentation_masks"
VIZ_DIR    = BASE_PATH / "data" / "inference_output" / "visualizations"

for d in [UPLOAD_DIR, RESULT_DIR, MASK_DIR, VIZ_DIR]:
    d.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, str(BASE_PATH / "scripts"))


def _parse_bool(value, default=False):
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "on", "evet"}


def _load_env_file(path: Path):
    """Ek paket gerektirmeden .env yükler; web ayarlarında proje dosyasını esas alır."""
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        value = value.split("#", 1)[0].strip().strip('"').strip("'")
        key = key.strip()
        # Web çalışma ayarlarının tek kaynağı proje .env dosyasıdır. Böylece
        # IDE/önceki terminalden kalan 100 MB gibi eski değerler yeni servisi ezemez.
        if key in {
            "PANCREAS_DEBUG", "MAX_UPLOAD_MB", "MAX_UPLOAD_FILES",
            "MODEL_TIMEOUT_SECONDS", "MODEL_CHECKPOINT", "FLASK_PORT",
        }:
            os.environ[key] = value
        else:
            os.environ.setdefault(key, value)


_load_env_file(BASE_PATH / ".env")
try:
    with open(BASE_PATH / "config.json", encoding="utf-8") as config_file:
        RUNTIME_CONFIG = json.load(config_file)
except (OSError, json.JSONDecodeError):
    RUNTIME_CONFIG = {}

WEB_CONFIG = RUNTIME_CONFIG.get("web", {})
DEBUG_ENABLED = _parse_bool(
    os.environ.get("PANCREAS_DEBUG", os.environ.get("FLASK_DEBUG")),
    WEB_CONFIG.get("debug", False),
)
MAX_UPLOAD_MB = int(os.environ.get("MAX_UPLOAD_MB", WEB_CONFIG.get("max_upload_mb", 8192)))
MAX_UPLOAD_FILES = int(os.environ.get("MAX_UPLOAD_FILES", WEB_CONFIG.get("max_upload_files", 5000)))
MODEL_TIMEOUT_SECONDS = int(os.environ.get("MODEL_TIMEOUT_SECONDS", 1800))
MODEL_CHECKPOINT = os.environ.get("MODEL_CHECKPOINT", "checkpoint_final.pth").strip()
TUMOR_MODEL_3D_CONFIG = RUNTIME_CONFIG.get("tumor_model_3d", {})
ANATOMICAL_GATE_CONFIG = RUNTIME_CONFIG.get("anatomical_gate", {})

logger = logging.getLogger("pancreas_ai")
logger.handlers.clear()
logger.propagate = False
logger.setLevel(logging.DEBUG if DEBUG_ENABLED else logging.WARNING)
_log_handler = logging.StreamHandler()
_log_handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
logger.addHandler(_log_handler)
logging.getLogger("werkzeug").setLevel(logging.INFO if DEBUG_ENABLED else logging.WARNING)


def debug_log(step: str, message: str, *args):
    """DEBUG=False olduğunda hiçbir adım/debug satırı üretmez."""
    if DEBUG_ENABLED:
        logger.debug("[%s] " + message, step, *args)


_PROGRESS = {}
_JOB_RESULTS = {}
_JOB_LOCK = threading.Lock()
_MODEL_RUN_LOCK = threading.Lock()


def update_progress(job_id: str, percent: int, stage: str, detail: str = ""):
    if not job_id:
        return
    safe_id = secure_filename(job_id)[:80]
    if not safe_id:
        return
    now = time.time()
    payload = {
        "job_id": safe_id,
        "percent": max(0, min(100, int(percent))),
        "stage": stage,
        "detail": detail,
        "updated_at": now,
    }
    with _JOB_LOCK:
        _PROGRESS[safe_id] = payload
        cutoff = now - 21600
        for store in (_PROGRESS, _JOB_RESULTS):
            stale = [key for key, value in store.items() if value.get("updated_at", now) < cutoff]
            for key in stale:
                store.pop(key, None)
    debug_log("İLERLEME", "%s%% - %s%s", payload["percent"], stage,
              f" ({detail})" if detail else "")

# ============================================================
# FLASK UYGULAMASI
# ============================================================
class DiskSpoolingRequest(FlaskRequest):
    """Çoklu DICOM yüklemesinde dosyaları 64 KB sonrasında RAM yerine diske taşır."""

    def _get_file_stream(
        self, total_content_length, content_type, filename=None, content_length=None
    ):
        return tempfile.SpooledTemporaryFile(max_size=64 * 1024, mode="rb+")


app = Flask(__name__, template_folder="templates", static_folder="static")
app.request_class = DiskSpoolingRequest
app.secret_key = os.urandom(24)
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_MB * 1024 * 1024
app.config["MAX_FORM_PARTS"] = MAX_UPLOAD_FILES
app.config["MAX_FORM_MEMORY_SIZE"] = 10 * 1024 * 1024
app.config["UPLOAD_FOLDER"]      = str(UPLOAD_DIR)

ALLOWED_EXTENSIONS = {".nii", ".nii.gz", ".dcm", ".dicom", ".zip", ".png", ".jpg", ".jpeg"}


def allowed_file(filename: str) -> bool:
    fn = filename.lower()
    return (fn.endswith(".nii.gz") or
            any(fn.endswith(ext) for ext in [".nii", ".dcm", ".dicom", ".zip", ".png", ".jpg", ".jpeg"]))


def _normalize_dicom_text(*values) -> str:
    """Türkçe karakterleri de kapsayan, seri karşılaştırmasına uygun metin üretir."""
    joined = " ".join(str(value or "") for value in values)
    normalized = unicodedata.normalize("NFKD", joined)
    return " ".join(
        "".join(char for char in normalized if not unicodedata.combining(char))
        .lower().replace("_", " ").replace("-", " ").split()
    )


def _score_dicom_series(headers):
    """Bir DICOM serisinin portal-venöz abdomen CT olma uygunluğunu puanlar."""
    import numpy as np

    dataset = headers[0][1]
    modality = str(getattr(dataset, "Modality", "")).upper()
    if modality != "CT":
        return None

    sop_uid = str(getattr(dataset, "SOPClassUID", ""))
    ct_sop_uids = {
        "1.2.840.10008.5.1.4.1.1.2",    # CT Image Storage
        "1.2.840.10008.5.1.4.1.1.2.1",  # Enhanced CT Image Storage
        "1.2.840.10008.5.1.4.1.1.2.2",  # Legacy Converted Enhanced CT
    }
    if sop_uid and sop_uid not in ct_sop_uids:
        return None

    description = _normalize_dicom_text(getattr(dataset, "SeriesDescription", ""))
    body_part = _normalize_dicom_text(getattr(dataset, "BodyPartExamined", ""))
    image_type = _normalize_dicom_text(*getattr(dataset, "ImageType", []))
    kernel = _normalize_dicom_text(getattr(dataset, "ConvolutionKernel", ""))
    reject_text = f"{description} {image_type}"
    rejected_terms = (
        "topogram", "localizer", "scout", "premonitoring", "monitoring",
        "patient protocol", "dose report", "examination report",
    )
    if any(term in reject_text for term in rejected_terms):
        return None

    score = min(len(headers), 500) * 0.4
    reasons = [f"kesit={len(headers)}"]

    if any(term in body_part for term in ("abdomen", "abdominal", "batin", "karin")):
        score += 2000
        reasons.append("BodyPart=ABDOMEN")
    elif "pelvis" in body_part:
        score += 800
        reasons.append("BodyPart=PELVIS")
    if any(term in body_part for term in ("chest", "thorax", "toraks", "neck", "boyun", "head", "brain")):
        score -= 1600
        reasons.append(f"uygunsuz BodyPart={body_part}")

    abdomen_terms = ("abdomen", "abdominal", "tum batin", "batin", "karin", "pankreas", "pancreas")
    if any(term in description for term in abdomen_terms):
        score += 1200
        reasons.append("abdomen açıklaması")
    non_abdomen_terms = (
        "thorax", "toraks", "chest", "lung", "akciger", "neck", "boyun",
        "head", "brain", "kranium", "servikal",
    )
    if any(term in description for term in non_abdomen_terms):
        score -= 1300
        reasons.append("abdomen dışı açıklama")

    if any(term in description for term in ("venoz", "venous", "portal", "70 sn", "70 sec")):
        score += 250
        reasons.append("portal/venöz faz")
    elif any(term in description for term in ("arterial", "arteryel", "25 sn", "25 sec")):
        score += 80
        reasons.append("arteryel faz")

    if "axial" in image_type:
        score += 50
        reasons.append("aksiyel")
    if str(getattr(dataset, "ContrastBolusAgent", "")).strip():
        score += 50
        reasons.append("IV kontrast")
    if any(term in kernel for term in ("br", "b30", "b31", "b36", "soft", "standard")):
        score += 100
        reasons.append("yumuşak doku kerneli")
    if any(term in kernel for term in ("lung", "bl60", "b70", "sharp")):
        score -= 500
        reasons.append("akciğer/keskin kernel")

    try:
        thickness = float(dataset.SliceThickness)
        if 0.5 <= thickness <= 3.5:
            score += 100
            reasons.append(f"kesit kalınlığı={thickness:g}")
        elif thickness > 5:
            score -= 200
    except Exception:
        pass

    positions = []
    for _, item, _, _ in headers:
        try:
            orientation = np.asarray(item.ImageOrientationPatient, dtype=float)
            position = np.asarray(item.ImagePositionPatient, dtype=float)
            normal = np.cross(orientation[:3], orientation[3:])
            positions.append(float(np.dot(position, normal)))
        except Exception:
            continue
    unique_positions = len({round(value, 3) for value in positions})
    if unique_positions > 10:
        score += 100
        reasons.append(f"uzamsal kesit={unique_positions}")
    elif len(headers) > 2 and unique_positions <= 1:
        score -= 1500
        reasons.append("aynı konum tekrarı")

    return score, reasons


def _build_dicom_nifti_affine(first_header, slice_normal, slice_spacing):
    """Map numpy ``(row, column, slice)`` indices from DICOM LPS to NIfTI RAS."""
    import numpy as np

    try:
        orientation = np.asarray(first_header.ImageOrientationPatient, dtype=float)
        origin_lps = np.asarray(first_header.ImagePositionPatient, dtype=float)
        pixel_spacing = np.asarray(first_header.PixelSpacing, dtype=float)
    except Exception as exc:
        raise ValueError(
            "DICOM hasta geometrisi eksik (ImageOrientationPatient, "
            "ImagePositionPatient veya PixelSpacing)."
        ) from exc

    if orientation.shape != (6,) or origin_lps.shape != (3,) or pixel_spacing.shape != (2,):
        raise ValueError("DICOM hasta geometrisi beklenen boyutta değil.")
    if not np.all(np.isfinite(orientation)) or not np.all(np.isfinite(origin_lps)):
        raise ValueError("DICOM yönelim/konum değerleri geçersiz.")
    if not np.all(np.isfinite(pixel_spacing)) or np.any(pixel_spacing <= 0):
        raise ValueError("DICOM PixelSpacing değerleri geçersiz.")

    # DICOM IOP: ilk üç değer sütun indeksi boyunca, son üç değer satır
    # indeksi boyunca hasta yönünü verir. PixelSpacing ise (satır, sütun)
    # sırasındadır. Hacim dizimiz (satır, sütun, kesit) olduğundan affine
    # eksenlerinin bu sırada kurulması gerekir.
    column_index_direction_lps = orientation[:3]
    row_index_direction_lps = orientation[3:]
    normal_lps = np.asarray(slice_normal, dtype=float)
    normal_norm = float(np.linalg.norm(normal_lps))
    if not np.isfinite(normal_norm) or normal_norm < 1e-6:
        raise ValueError("DICOM kesit normali hesaplanamadı.")
    normal_lps /= normal_norm

    affine_lps = np.eye(4, dtype=float)
    affine_lps[:3, 0] = row_index_direction_lps * float(pixel_spacing[0])
    affine_lps[:3, 1] = column_index_direction_lps * float(pixel_spacing[1])
    affine_lps[:3, 2] = normal_lps * float(slice_spacing)
    affine_lps[:3, 3] = origin_lps

    # DICOM dünya koordinatları LPS, NIfTI ise RAS kullanır.
    lps_to_ras = np.diag([-1.0, -1.0, 1.0, 1.0])
    affine_ras = lps_to_ras @ affine_lps
    if not np.all(np.isfinite(affine_ras)) or abs(np.linalg.det(affine_ras[:3, :3])) < 1e-8:
        raise ValueError("DICOM'dan geçerli NIfTI affine üretilemedi.")
    return affine_ras


def _safe_extract_zip(zip_ref, destination: Path):
    destination_resolved = destination.resolve()
    for member in zip_ref.infolist():
        member_path = (destination / member.filename).resolve()
        try:
            member_path.relative_to(destination_resolved)
        except ValueError as exc:
            raise ValueError(f"Güvensiz ZIP yolu: {member.filename}") from exc
    zip_ref.extractall(destination)


def convert_image_to_nifti(input_path: Path, output_nii_path: Path, progress_callback=None) -> bool:
    """Görsel kesitleri, hacim boyutunda RAM kopyası oluşturmadan NIfTI'ye dönüştürür."""
    import zipfile
    from PIL import Image
    import numpy as np
    import nibabel as nib

    extract_dir = None
    temp_volume_path = None
    volume = None
    try:
        output_nii_path.parent.mkdir(parents=True, exist_ok=True)
        img_files = []

        if input_path.is_dir():
            img_files = sorted(
                f for f in input_path.rglob("*")
                if f.suffix.lower() in [".png", ".jpg", ".jpeg"] and f.is_file()
            )
        elif input_path.name.lower().endswith(".zip"):
            extract_dir = input_path.parent / f"extracted_img_{uuid.uuid4().hex[:8]}"
            extract_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(input_path, "r") as zip_ref:
                _safe_extract_zip(zip_ref, extract_dir)
            img_files = sorted(
                f for f in extract_dir.rglob("*")
                if f.suffix.lower() in [".png", ".jpg", ".jpeg"] and f.is_file()
            )
        elif input_path.suffix.lower() in [".png", ".jpg", ".jpeg"]:
            img_files = [input_path]

        if not img_files:
            return False

        with Image.open(img_files[0]) as first_image:
            width, height = first_image.size

        temp_volume_path = output_nii_path.parent / f".{uuid.uuid4().hex}.img-volume.dat"
        volume = np.memmap(
            temp_volume_path, dtype=np.float32, mode="w+",
            shape=(height, width, len(img_files)),
        )
        total = len(img_files)
        for index, image_path in enumerate(img_files):
            with Image.open(image_path) as pil_image:
                gray = pil_image.convert("L")
                if gray.size != (width, height):
                    raise ValueError("Görsel kesit boyutları birbiriyle uyuşmuyor.")
                slice_array = np.asarray(gray, dtype=np.float32)
            volume[:, :, index] = (slice_array / 255.0) * 400.0 - 150.0
            if progress_callback and (index % 25 == 0 or index + 1 == total):
                progress_callback(index + 1, total, "Görsel kesitler hacme dönüştürülüyor")

        volume.flush()
        nifti_image = nib.Nifti1Image(volume, np.eye(4))
        nifti_image.set_data_dtype(np.float32)
        nib.save(nifti_image, str(output_nii_path))
        del nifti_image, volume
        volume = None
        temp_volume_path.unlink(missing_ok=True)
        return True

    except Exception as exc:
        debug_log("GÖRSEL DÖNÜŞÜM", "Hata: %s", exc)
        return False
    finally:
        if volume is not None:
            del volume
        if temp_volume_path:
            temp_volume_path.unlink(missing_ok=True)
        if extract_dir:
            shutil.rmtree(extract_dir, ignore_errors=True)
        gc.collect()


def convert_dicom_to_nifti(input_path: Path, output_nii_path: Path, progress_callback=None) -> bool:
    """
    Çok-serili DICOM klasöründen pankreas için uygun abdomen CT serisini seçer.
    Piksel hacmi float32 disk eşlemeli oluşturulur; modelin giriş değerleri değiştirilmez.
    """
    import zipfile
    import pydicom
    import numpy as np
    import nibabel as nib

    extract_dir = None
    temp_volume_path = None
    volume = None
    try:
        output_nii_path.parent.mkdir(parents=True, exist_ok=True)
        if input_path.is_dir():
            dcm_files = [
                path for path in input_path.rglob("*")
                if path.suffix.lower() in [".dcm", ".dicom", ""] and path.is_file()
            ]
        elif input_path.name.lower().endswith(".zip"):
            extract_dir = input_path.parent / f"extracted_{uuid.uuid4().hex[:8]}"
            extract_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(input_path, "r") as zip_ref:
                _safe_extract_zip(zip_ref, extract_dir)
            dcm_files = [
                path for path in extract_dir.rglob("*")
                if path.suffix.lower() in [".dcm", ".dicom", ""] and path.is_file()
            ]
        elif input_path.name.lower().endswith((".dcm", ".dicom")):
            dcm_files = [input_path]
        else:
            dcm_files = []

        if not dcm_files:
            return False

        series_groups = {}
        header_total = len(dcm_files)
        for index, dicom_path in enumerate(dcm_files):
            try:
                dataset = pydicom.dcmread(
                    str(dicom_path), stop_before_pixels=True, force=True,
                    specific_tags=[
                        "InstanceNumber", "SliceLocation", "ImagePositionPatient",
                        "ImageOrientationPatient", "Rows", "Columns", "PixelSpacing",
                        "SeriesInstanceUID", "SeriesNumber", "SeriesDescription",
                        "ProtocolName", "BodyPartExamined", "Modality", "ImageType",
                        "SliceThickness", "SpacingBetweenSlices", "ConvolutionKernel",
                        "ContrastBolusAgent", "SOPClassUID",
                    ],
                )
                rows = int(getattr(dataset, "Rows", 0))
                columns = int(getattr(dataset, "Columns", 0))
                if rows and columns:
                    series_uid = str(getattr(dataset, "SeriesInstanceUID", "")).strip()
                    group_key = series_uid or f"NO_UID::{dicom_path.parent}"
                    series_groups.setdefault(group_key, []).append(
                        (dicom_path, dataset, rows, columns)
                    )
            except Exception:
                continue
            finally:
                if progress_callback and (index % 50 == 0 or index + 1 == header_total):
                    progress_callback(index + 1, header_total, "DICOM serileri taranıyor")

        candidates = []
        for series_uid, headers in series_groups.items():
            dimensions = {(item[2], item[3]) for item in headers}
            if len(dimensions) != 1:
                continue
            description = str(getattr(headers[0][1], "SeriesDescription", "")).lower()
            scored = _score_dicom_series(headers)
            if scored is None:
                continue
            score, reasons = scored
            candidates.append((score, len(headers), series_uid, headers, description, reasons))

        if not candidates:
            debug_log("DICOM DÖNÜŞÜM", "Uygun, tutarlı boyutlu CT serisi bulunamadı")
            return False

        for score, count, _, _, candidate_description, reasons in sorted(candidates, reverse=True):
            debug_log(
                "DICOM SERİ SEÇİMİ", "puan=%.1f, kesit=%s, seri='%s', neden=%s",
                score, count, candidate_description, ", ".join(reasons),
            )

        selected_score, _, selected_uid, slice_headers, description, selected_reasons = max(
            candidates, key=lambda item: (item[0], item[1])
        )
        # Toraks/boyun gibi açıkça uygunsuz bir seriyi, sırf eldeki adayların en
        # iyisi olduğu için pankreas modeline göndermek yalancı pozitif üretir.
        if selected_score < 0:
            debug_log(
                "DICOM DÖNÜŞÜM", "En iyi CT serisi abdomen için uygun değil: "
                "puan=%.1f, seri='%s'", selected_score, description,
            )
            return False
        debug_log(
            "DICOM DÖNÜŞÜM",
            "%s seri içinden '%s' seçildi: %s kesit; neden=%s (UID=%s)",
            len(series_groups), description, len(slice_headers),
            ", ".join(selected_reasons), selected_uid,
        )

        def get_spatial_position(dataset):
            try:
                orientation = np.asarray(dataset.ImageOrientationPatient, dtype=float)
                position = np.asarray(dataset.ImagePositionPatient, dtype=float)
                normal = np.cross(orientation[:3], orientation[3:])
                return float(np.dot(position, normal))
            except Exception:
                return None

        def get_slice_order(dataset):
            spatial_position = get_spatial_position(dataset)
            if spatial_position is not None:
                return 0, spatial_position
            for attribute in ("SliceLocation", "InstanceNumber"):
                try:
                    return 1, float(getattr(dataset, attribute))
                except Exception:
                    continue
            return 2, 0.0

        slice_headers.sort(key=lambda item: (get_slice_order(item[1]), str(item[0])))
        spatial_slice_count = len({
            round(value, 3) for value in (
                get_spatial_position(item[1]) for item in slice_headers
            ) if value is not None
        })
        if len(slice_headers) < 16 or spatial_slice_count < 10:
            debug_log(
                "DICOM DÖNÜŞÜM", "3B abdomen analizi için yetersiz kesit: "
                "dosya=%s, uzamsal=%s", len(slice_headers), spatial_slice_count,
            )
            return False
        rows, columns = slice_headers[0][2], slice_headers[0][3]

        first_header = slice_headers[0][1]
        try:
            pixel_spacing = [float(value) for value in first_header.PixelSpacing]
            row_spacing, column_spacing = pixel_spacing[0], pixel_spacing[1]
        except Exception:
            row_spacing = column_spacing = 1.0
        spatial_positions = [
            value for value in (get_spatial_position(item[1]) for item in slice_headers)
            if value is not None
        ]
        unique_positions = np.asarray(sorted(set(round(value, 6) for value in spatial_positions)))
        if unique_positions.size > 1:
            slice_spacing = float(np.median(np.abs(np.diff(unique_positions))))
        else:
            try:
                slice_spacing = abs(float(getattr(first_header, "SpacingBetweenSlices")))
            except Exception:
                try:
                    slice_spacing = abs(float(first_header.SliceThickness))
                except Exception:
                    slice_spacing = 1.0
        if not np.isfinite(slice_spacing) or slice_spacing <= 0:
            slice_spacing = 1.0

        try:
            first_orientation = np.asarray(first_header.ImageOrientationPatient, dtype=float)
            slice_normal = np.cross(first_orientation[:3], first_orientation[3:])
            nifti_affine = _build_dicom_nifti_affine(
                first_header, slice_normal=slice_normal, slice_spacing=slice_spacing
            )
        except ValueError as exc:
            debug_log("DICOM GEOMETRİ", "Geçersiz hasta geometrisi: %s", exc)
            return False
        debug_log(
            "DICOM GEOMETRİ", "boyut=%sx%sx%s, spacing=%.4fx%.4fx%.4f mm, affine=%s",
            rows, columns, len(slice_headers), row_spacing, column_spacing, slice_spacing,
            np.array2string(nifti_affine, precision=3, suppress_small=True),
        )
        temp_volume_path = output_nii_path.parent / f".{uuid.uuid4().hex}.dcm-volume.dat"
        volume = np.memmap(
            temp_volume_path, dtype=np.float32, mode="w+",
            shape=(rows, columns, len(slice_headers)),
        )

        total = len(slice_headers)

        for index, (dicom_path, _, _, _) in enumerate(slice_headers):
            dataset = pydicom.dcmread(str(dicom_path), force=True)
            pixel_array = np.asarray(dataset.pixel_array, dtype=np.float32)
            if pixel_array.ndim != 2 or pixel_array.shape != (rows, columns):
                raise ValueError(f"Uyumsuz DICOM kesiti: {dicom_path.name}")
            pixel_array *= float(getattr(dataset, "RescaleSlope", 1.0))
            pixel_array += float(getattr(dataset, "RescaleIntercept", 0.0))
            if not np.all(np.isfinite(pixel_array)):
                raise ValueError(f"Geçersiz HU değeri içeren DICOM kesiti: {dicom_path.name}")
            # Bazı tarayıcılar FOV dışını -8192 gibi aykırı değerlerle doldurur.
            # Eğitim CT'lerinin tanısal HU aralığını koruyup dolgu/metal uçlarını
            # yumuşak-doku normalizasyonunu bozmayacak aralığa sınırla.
            np.clip(pixel_array, -1024.0, 3071.0, out=pixel_array)
            volume[:, :, index] = pixel_array
            del dataset, pixel_array
            if progress_callback and (index % 25 == 0 or index + 1 == total):
                progress_callback(index + 1, total, "Seçilen CT serisi NIfTI'ye dönüştürülüyor")

        volume.flush()
        nifti_image = nib.Nifti1Image(volume, nifti_affine)
        nifti_image.set_data_dtype(np.float32)
        nifti_image.set_qform(nifti_affine, code=1)
        nifti_image.set_sform(nifti_affine, code=1)
        nib.save(nifti_image, str(output_nii_path))
        del nifti_image, volume
        volume = None
        temp_volume_path.unlink(missing_ok=True)
        return True

    except Exception as exc:
        debug_log("DICOM DÖNÜŞÜM", "Hata: %s", exc)
        return False
    finally:
        if volume is not None:
            del volume
        if temp_volume_path:
            temp_volume_path.unlink(missing_ok=True)
        if extract_dir:
            shutil.rmtree(extract_dir, ignore_errors=True)
        gc.collect()


def load_nnunet_env():
    """nnU-Net ortam değişkenlerini yükler."""
    config_path = BASE_PATH / "config.json"
    if config_path.exists():
        with open(config_path) as f:
            config = json.load(f)
        paths = config.get("paths", {})
        for key, path_key in [
            ("nnUNet_raw",          "nnunet_raw"),
            ("nnUNet_preprocessed", "nnunet_preprocessed"),
            ("nnUNet_results",      "nnunet_results"),
        ]:
            if not os.environ.get(key) and path_key in paths:
                os.environ[key] = paths[path_key]


load_nnunet_env()


# ============================================================
# ROUTES
# ============================================================
@app.route("/")
def index():
    """Ana sayfa."""
    return render_template("index.html")


@app.route("/api/progress/<job_id>")
def progress_status(job_id):
    safe_id = secure_filename(job_id)[:80]
    with _JOB_LOCK:
        payload = dict(_PROGRESS.get(safe_id, {
            "job_id": safe_id,
            "percent": 0,
            "stage": "Yükleme bekleniyor",
            "detail": "",
        }))
    payload.pop("updated_at", None)
    return jsonify(payload)


@app.route("/result/<job_id>")
def job_result(job_id):
    safe_id = secure_filename(job_id)[:80]
    with _JOB_LOCK:
        stored = _JOB_RESULTS.get(safe_id)
        payload = dict(stored) if stored else None
    if not payload:
        flash("Analiz sonucu bulunamadı veya süresi doldu.", "warning")
        return redirect(url_for("index"))
    return render_template(
        "result.html",
        result=payload["result"],
        case_id=payload["case_id"],
        original_filename=payload["original_filename"],
    )


@app.errorhandler(RequestEntityTooLarge)
def handle_large_upload(_error):
    message = f"Yükleme sunucu sınırını aşıyor. İzin verilen toplam boyut: {MAX_UPLOAD_MB} MB."
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return jsonify({"error": message}), 413
    flash(message, "danger")
    return redirect(url_for("index"))


def _is_ajax_request() -> bool:
    return request.headers.get("X-Requested-With") == "XMLHttpRequest"


def _safe_relative_upload_path(filename: str) -> Path:
    """Klasör yapısını korur ve gönderilen yolun hedef dışına çıkmasını önler."""
    normalized = (filename or "").replace("\\", "/")
    parts = [secure_filename(part) for part in normalized.split("/")]
    parts = [part for part in parts if part and part not in {".", ".."}]
    return Path(*parts) if parts else Path(f"upload_{uuid.uuid4().hex}")


def _conversion_progress(job_id: str):
    def callback(done: int, total: int, detail: str):
        detail_lower = detail.lower()
        if "taran" in detail_lower or "seri" in detail_lower:
            percent = 47 + int(5 * done / max(1, total))
        else:
            percent = 52 + int(8 * done / max(1, total))
        update_progress(job_id, percent, "Kesitler NIfTI hacmine dönüştürülüyor", detail)
    return callback


def _upload_error(job_id: str, message: str, status: int = 400):
    update_progress(job_id, 0, "İşlem başarısız", message)
    if _is_ajax_request():
        return jsonify({"error": message}), status
    flash(message, "danger")
    return redirect(url_for("index"))


def _upload_success(job_id: str, result: dict, case_id: str, original_filename: str):
    update_progress(job_id, 100, "Analiz tamamlandı", "Sonuç sayfası hazırlanıyor")
    if _is_ajax_request():
        safe_id = secure_filename(job_id)[:80]
        with _JOB_LOCK:
            _JOB_RESULTS[safe_id] = {
                "result": result,
                "case_id": case_id,
                "original_filename": original_filename,
                "updated_at": time.time(),
            }
        return jsonify({"redirect_url": url_for("job_result", job_id=safe_id)})
    return render_template(
        "result.html", result=result, case_id=case_id,
        original_filename=original_filename,
    )


def get_clean_basename(filename: str) -> tuple[str, str]:
    """
    Yüklenen dosya adından uzantısız temel adı (base_name) ve tam orijinal adı (original_filename) döndürür.
    Örn: 'PancreasAI_DICOM_case_291e22b5.dcm' -> ('PancreasAI_DICOM_case_291e22b5', 'PancreasAI_DICOM_case_291e22b5.dcm')
    """
    if not filename:
        return "uploaded_file", "uploaded_file"

    original_filename = secure_filename(filename)
    if not original_filename:
        original_filename = "uploaded_file"

    base_name = original_filename
    for ext in [".nii.gz", ".nii", ".dcm", ".dicom", ".zip", ".png", ".jpg", ".jpeg"]:
        if base_name.lower().endswith(ext):
            base_name = base_name[:-len(ext)]
            break

    if not base_name:
        base_name = "uploaded_file"

    return base_name, original_filename


@app.route("/upload", methods=["POST"])
def upload_file():
    """Büyük CT klasörlerini disk üzerinden işler ve gerçek ilerlemeyi yayınlar."""
    job_id = secure_filename(request.args.get("job_id", ""))[:80] or uuid.uuid4().hex
    update_progress(job_id, 1, "Yükleme başlatıldı", "Dosya listesi alınıyor")
    files = request.files.getlist("file") or request.files.getlist("files")
    if not files or not files[0] or not files[0].filename:
        return _upload_error(job_id, "Dosya veya klasör seçilmedi!")
    if len(files) > MAX_UPLOAD_FILES:
        return _upload_error(
            job_id,
            f"En fazla {MAX_UPLOAD_FILES} dosya yüklenebilir; {len(files)} dosya seçildi.",
            413,
        )

    debug_log("YÜKLEME", "%s dosya alındı", len(files))
    if len(files) > 1:
        first_name = files[0].filename
        normalized_first = first_name.replace("\\", "/")
        first_parts = normalized_first.split("/")
        fallback_name, _ = get_clean_basename(first_name)
        folder_name = first_parts[0] if len(first_parts) > 1 else fallback_name
        case_id = secure_filename(folder_name) or "uploaded_folder"
        temp_folder = UPLOAD_DIR / f"folder_{case_id}_{uuid.uuid4().hex[:8]}"
        temp_folder.mkdir(parents=True, exist_ok=True)
        try:
            total_files = len(files)
            for index, storage in enumerate(files):
                if storage and storage.filename:
                    save_path = temp_folder / _safe_relative_upload_path(storage.filename)
                    save_path.parent.mkdir(parents=True, exist_ok=True)
                    storage.save(str(save_path))
                if index % 25 == 0 or index + 1 == total_files:
                    percent = 36 + int(10 * (index + 1) / total_files)
                    update_progress(
                        job_id, percent, "Dosyalar diske kaydediliyor",
                        f"{index + 1}/{total_files} dosya",
                    )

            target_nii_path = UPLOAD_DIR / f"{case_id}_0000.nii.gz"
            callback = _conversion_progress(job_id)
            update_progress(job_id, 47, "DICOM serileri inceleniyor", "Karın serisi seçiliyor")
            converted = convert_dicom_to_nifti(temp_folder, target_nii_path, callback)
            if not converted:
                converted = convert_image_to_nifti(temp_folder, target_nii_path, callback)
            if not converted:
                return _upload_error(
                    job_id,
                    "Yüklenen klasörde tutarlı bir DICOM CT serisi veya PNG/JPG kesitleri bulunamadı.",
                )

            result = analyze_ct(
                target_nii_path, case_id, original_filename=folder_name, job_id=job_id
            )
            if result.get("error"):
                return _upload_error(job_id, f"Analiz Hatası: {result['error']}", 500)
            return _upload_success(job_id, result, case_id, folder_name)
        finally:
            shutil.rmtree(temp_folder, ignore_errors=True)

    storage = files[0]
    if not allowed_file(storage.filename):
        return _upload_error(
            job_id,
            "Geçersiz dosya formatı! .nii, .nii.gz, .dcm, .dicom, .zip, .png, .jpg veya .jpeg kullanın.",
        )

    case_id, original_filename = get_clean_basename(storage.filename)
    raw_save_path = UPLOAD_DIR / f"raw_{case_id}_{original_filename}"
    update_progress(job_id, 36, "Dosya diske kaydediliyor", original_filename)
    storage.save(str(raw_save_path))
    update_progress(job_id, 46, "Dosya kaydedildi", "Format denetleniyor")

    target_nii_path = UPLOAD_DIR / f"{case_id}_0000.nii.gz"
    fn_lower = original_filename.lower()
    callback = _conversion_progress(job_id)
    converted = True
    if any(fn_lower.endswith(fmt) for fmt in [".png", ".jpg", ".jpeg"]):
        converted = convert_image_to_nifti(raw_save_path, target_nii_path, callback)
    elif fn_lower.endswith((".dcm", ".dicom")):
        converted = convert_dicom_to_nifti(raw_save_path, target_nii_path, callback)
    elif fn_lower.endswith(".zip"):
        converted = convert_dicom_to_nifti(raw_save_path, target_nii_path, callback)
        if not converted:
            converted = convert_image_to_nifti(raw_save_path, target_nii_path, callback)
    elif fn_lower.endswith(".nii.gz"):
        shutil.copy2(str(raw_save_path), str(target_nii_path))
    else:
        import gzip
        with open(raw_save_path, "rb") as source:
            with gzip.open(target_nii_path, "wb", compresslevel=6) as destination:
                shutil.copyfileobj(source, destination)
    raw_save_path.unlink(missing_ok=True)
    if not converted:
        return _upload_error(job_id, "Dosya NIfTI hacmine dönüştürülemedi.")

    result = analyze_ct(
        target_nii_path, case_id, original_filename=original_filename, job_id=job_id
    )
    if result.get("error"):
        return _upload_error(job_id, f"Analiz Hatası: {result['error']}", 500)
    return _upload_success(job_id, result, case_id, original_filename)


@app.route("/api/analyze", methods=["POST"])
def api_analyze():
    """REST API endpoint — JSON yanıt döndürür."""
    if "file" not in request.files:
        return jsonify({"error": "Dosya bulunamadı"}), 400

    file = request.files["file"]
    if not allowed_file(file.filename):
        return jsonify({"error": "Geçersiz dosya formatı (.nii, .nii.gz, .dcm, .dicom, .zip, .png, .jpg, .jpeg desteklenir)"}), 400

    base_name, original_filename = get_clean_basename(file.filename)
    case_id = base_name

    raw_save_path = UPLOAD_DIR / f"raw_{case_id}_{original_filename}"
    file.save(str(raw_save_path))

    target_nii_path = UPLOAD_DIR / f"{case_id}_0000.nii.gz"
    fn_lower = original_filename.lower()

    if any(fn_lower.endswith(fmt) for fmt in [".png", ".jpg", ".jpeg"]):
        converted = convert_image_to_nifti(raw_save_path, target_nii_path)
        if not converted:
            raw_save_path.unlink(missing_ok=True)
            return jsonify({"error": "Görsel dönüştürme başarısız."}), 400
    elif fn_lower.endswith(".dcm") or fn_lower.endswith(".dicom"):
        converted = convert_dicom_to_nifti(raw_save_path, target_nii_path)
        if not converted:
            raw_save_path.unlink(missing_ok=True)
            return jsonify({"error": "DICOM dönüştürme başarısız."}), 400
    elif fn_lower.endswith(".zip"):
        converted = convert_dicom_to_nifti(raw_save_path, target_nii_path)
        if not converted:
            converted = convert_image_to_nifti(raw_save_path, target_nii_path)
        if not converted:
            raw_save_path.unlink(missing_ok=True)
            return jsonify({"error": "ZIP dönüştürme başarısız."}), 400
    elif fn_lower.endswith(".nii.gz"):
        shutil.copy2(str(raw_save_path), str(target_nii_path))
    else:
        import gzip
        with open(raw_save_path, "rb") as f_in:
            with gzip.open(target_nii_path, "wb", compresslevel=6) as f_out:
                shutil.copyfileobj(f_in, f_out)

    raw_save_path.unlink(missing_ok=True)

    result = analyze_ct(target_nii_path, case_id, original_filename=original_filename)
    return jsonify(result)


@app.route("/history")
def history():
    """Geçmiş analizleri listele."""
    results_dir = BASE_PATH / "metrics"
    history_items = []

    for json_file in sorted(results_dir.glob("inference_results_*.json"),
                            reverse=True)[:20]:
        try:
            with open(json_file) as f:
                data = json.load(f)
            history_items.append(data)
        except Exception:
            pass

    return render_template("history.html", history=history_items)


@app.route("/static/results/<filename>")
def serve_result(filename):
    return send_from_directory(str(RESULT_DIR), filename)


# ============================================================
# ANALİZ FONKSİYONU
# ============================================================
def _count_mask_labels(mask_data) -> tuple[int, int]:
    """Büyük maskede hacim boyutunda geçici bool dizileri oluşturmadan sayar."""
    import numpy as np
    mask_view = np.squeeze(mask_data)
    if mask_view.ndim < 3:
        return int(np.count_nonzero(mask_view == 1)), int(np.count_nonzero(mask_view == 2))
    pancreas_voxels = 0
    tumor_voxels = 0
    for slice_index in range(mask_view.shape[2]):
        mask_slice = mask_view[:, :, slice_index]
        pancreas_voxels += int(np.count_nonzero(mask_slice == 1))
        tumor_voxels += int(np.count_nonzero(mask_slice == 2))
    return pancreas_voxels, tumor_voxels


def _postprocess_mask_anatomical_continuity(mask_data):
    """Ana pankreas bloğundan eksen boyunca uzak kopuk yalancı bileşenleri temizler."""
    import numpy as np
    try:
        from scipy import ndimage
    except ImportError:
        return mask_data, {"removed_voxels": 0, "removed_components": 0}

    mask = np.asarray(mask_data, dtype=np.uint8)
    organ = mask > 0
    structure = ndimage.generate_binary_structure(3, 2)
    components, component_count = ndimage.label(organ, structure=structure)
    if component_count <= 1:
        return mask, {"removed_voxels": 0, "removed_components": 0}

    counts = np.bincount(components.ravel())
    counts[0] = 0
    main_component = int(np.argmax(counts))
    main_points = np.argwhere(components == main_component)
    main_z_min = int(main_points[:, 2].min())
    main_z_max = int(main_points[:, 2].max())
    # Pankreas/tümörün hemen komşu, kopuk tahminlerini koru; yalnız anatomik
    # kesit bandından belirgin biçimde uzak bileşenleri çıkar.
    z_margin = 5
    removed_voxels = 0
    removed_components = 0
    for component_id in range(1, component_count + 1):
        if component_id == main_component:
            continue
        points = np.argwhere(components == component_id)
        component_z_min = int(points[:, 2].min())
        component_z_max = int(points[:, 2].max())
        is_distant = (
            component_z_max < main_z_min - z_margin or
            component_z_min > main_z_max + z_margin
        )
        if is_distant:
            selector = components == component_id
            removed_voxels += int(np.count_nonzero(selector))
            removed_components += 1
            mask[selector] = 0

    return mask, {
        "removed_voxels": removed_voxels,
        "removed_components": removed_components,
        "main_z_range": [main_z_min, main_z_max],
    }


def analyze_ct(
    ct_path: Path, case_id: str, original_filename: str = None, job_id: str = ""
) -> dict:
    """
    CT dosyasını analiz eder:
    1. Gerçek nnU-Net inference (simülasyon tamamen devre dışı)
    2. Segmentasyon maskesinden tümör kararı
    3. Görselleştirme

    Returns:
        Sonuç sözlüğü
    """
    start_time = time.time()
    if not original_filename:
        original_filename = f"{case_id}.dcm"

    result = {
        "case_id":           case_id,
        "filename":          original_filename,
        "original_filename": original_filename,
        "timestamp":         datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "prediction":        None,
        "has_tumor":         None,
        "error":             None,
        "viz_url":           None,
        "elapsed_s":         None,
    }

    try:
        import numpy as np
        import nibabel as nib

        # CT yükle
        ct_img  = nib.load(str(ct_path))
        result["ct_shape"] = list(ct_img.shape)
        del ct_img
        update_progress(job_id, 61, "Model hazırlanıyor", "CT hacmi doğrulandı")

        # Tek GPU üzerinde iki ağır model zinciri CUDA belleğini taşırmasın;
        # eşzamanlı web istekleri burada güvenli biçimde sıraya alınır.
        with _MODEL_RUN_LOCK:
            mask_data, err_msg, quality = _run_inference(
                ct_path, case_id, job_id=job_id
            )

        if mask_data is None:
            result["error"] = err_msg or "Model segmentasyon çıktısı elde edilemedi."
            result["prediction"] = "Model / Inference Hatası"
            result["elapsed_s"] = round(time.time() - start_time, 2)
            return result

        result["mode"] = (
            "ensemble_3d_gate"
            if "MONAI DiNTS 3B" in quality.get("models", [])
            else "anatomical_gate_indeterminate"
        )
        result["quality"] = quality

        # Tümör kararı yalnızca bağımsız 3B anatomik doğrulamadan gelir.
        update_progress(job_id, 90, "Maske analiz ediliyor", "3B kalite ölçümleri okunuyor")
        pancreas_voxels, tumor_voxels = _count_mask_labels(mask_data)
        has_tumor = quality.get("has_tumor")
        if not quality.get("pancreas_verified"):
            prediction_text = "Pankreas doğrulanamadı — karar verilemedi"
            confidence_label = "Doğrulanamadı"
        elif has_tumor:
            prediction_text = "Anatomik olarak doğrulanmış tümör adayı"
            confidence_label = "3B anatomik ölçütler geçti"
        else:
            prediction_text = "Doğrulanmış tümör adayı saptanmadı"
            confidence_label = "Pankreas 3B olarak doğrulandı"

        result["has_tumor"]       = has_tumor
        result["prediction"]      = prediction_text
        result["tumor_voxels"]    = tumor_voxels
        result["pancreas_voxels"] = pancreas_voxels
        result["tumor_ml"]         = quality.get("tumor_ml", 0.0)
        result["pancreas_ml"]      = quality.get("pancreas_ml", 0.0)
        result["raw_tumor_voxels"] = quality.get("raw_tumor_voxels", 0)
        result["nnunet_raw_tumor_voxels"] = quality.get("nnunet_raw_tumor_voxels", 0)
        result["dints_raw_tumor_voxels"] = quality.get("dints_raw_tumor_voxels", 0)
        result["rejected_tumor_voxels"] = quality.get("rejected_tumor_voxels", 0)
        result["cross_model_dice"] = quality.get("cross_model_dice")
        result["pancreas_verified"] = bool(quality.get("pancreas_verified"))
        result["quality_status"]   = quality.get("status", "indeterminate")
        result["quality_reason"]   = quality.get("reason")
        result["confidence"]       = confidence_label

        # Görselleştirme oluştur
        # Model tamamlandıktan sonra CT'yi float64 kopya oluşturmadan yükle.
        ct_img = nib.load(str(ct_path))
        ct_data = np.asanyarray(ct_img.dataobj)
        update_progress(job_id, 92, "Sonuç görseli hazırlanıyor", "Pankreas içeren 8 kesit seçiliyor")
        viz_path = VIZ_DIR / f"{case_id}_seg.png"
        _create_web_viz(ct_data, mask_data, result, viz_path)

        if viz_path.exists():
            # Web statik klasörüne kopyala
            web_viz = RESULT_DIR / f"{case_id}_seg.png"
            shutil.copy2(str(viz_path), str(web_viz))
            try:
                result["viz_url"] = url_for("static", filename=f"results/{case_id}_seg.png")
            except Exception:
                result["viz_url"] = f"/static/results/{case_id}_seg.png"

        # Maskeli DICOM paketi (.zip - 2D & 3D) oluştur
        try:
            from dicom_export import export_full_dicom_package
            clean_id = case_id
            for ext in [".zip", ".dcm", ".dicom", ".nii.gz", ".nii", ".png", ".jpg", ".jpeg"]:
                if clean_id.lower().endswith(ext):
                    clean_id = clean_id[:-len(ext)]
                    break
            if clean_id.lower().endswith("_maskeli_goruntu"):
                clean_id = clean_id[:-len("_maskeli_goruntu")]

            zip_filename = f"{clean_id}_maskeli_goruntu.zip"
            dicom_zip_path = RESULT_DIR / zip_filename
            update_progress(job_id, 95, "DICOM çıktıları hazırlanıyor", "2D ve 3D paket oluşturuluyor")

            def dicom_progress(done, total, detail):
                percent = 95 + int(4 * done / max(1, total))
                update_progress(job_id, percent, "DICOM çıktıları hazırlanıyor", detail)

            dicom_ok = export_full_dicom_package(
                ct_data, mask_data, clean_id, dicom_zip_path,
                progress_callback=dicom_progress,
            )
            if dicom_ok and dicom_zip_path.exists():
                result["dicom_url"] = f"/download_dicom/{clean_id}"
        except Exception as dcm_err:
            debug_log("DICOM", "Paket oluşturulamadı: %s", dcm_err)

        del ct_data, mask_data
        gc.collect()

    except Exception as e:
        result["error"] = str(e)
        result["prediction"] = "Hata"
        debug_log("ANALİZ", "Hata: %s", e)

    result["elapsed_s"] = round(time.time() - start_time, 2)
    return result


@app.route("/download_dicom/<case_id>")
def download_dicom(case_id):
    """Maskeli DICOM paketini (.zip) indir (<Orijinal_Dosya_Adi>_maskeli_goruntu.zip)."""
    clean_id = case_id
    for ext in [".zip", ".dcm", ".dicom", ".nii.gz", ".nii", ".png", ".jpg", ".jpeg"]:
        if clean_id.lower().endswith(ext):
            clean_id = clean_id[:-len(ext)]
            break
    if clean_id.lower().endswith("_maskeli_goruntu"):
        clean_id = clean_id[:-len("_maskeli_goruntu")]

    zip_filename = f"{clean_id}_maskeli_goruntu.zip"
    zip_path = RESULT_DIR / zip_filename

    if not zip_path.exists():
        fallback_path = RESULT_DIR / f"{case_id}.zip"
        if fallback_path.exists():
            zip_path = fallback_path

    if zip_path.exists():
        return send_from_directory(
            str(RESULT_DIR),
            zip_path.name,
            mimetype="application/zip",
            as_attachment=True,
            download_name=f"{clean_id}_maskeli_goruntu.zip"
        )
    else:
        flash("DICOM dosyası bulunamadı!", "danger")
        return redirect(url_for("index"))


def _run_dints_tumor_model(
    ct_path: Path, work_dir: Path, output_dir: Path, log_path: Path,
    job_id: str = "",
):
    """Resmî MONAI DiNTS 3B pankreas+tümör modelini bellek-güvenli çalıştırır."""
    if not _parse_bool(TUMOR_MODEL_3D_CONFIG.get("enabled"), True):
        return None, "3B tümör modeli kapalı; düşük kaliteli tek-model sonucu yayınlanmadı."

    python_path = Path(TUMOR_MODEL_3D_CONFIG.get(
        "python", ".venv_totalseg/Scripts/python.exe"
    ))
    bundle_dir = Path(TUMOR_MODEL_3D_CONFIG.get(
        "bundle_dir", "data/monai_bundles/pancreas_ct_dints_segmentation"
    ))
    if not python_path.is_absolute():
        python_path = BASE_PATH / python_path
    if not bundle_dir.is_absolute():
        bundle_dir = BASE_PATH / bundle_dir
    config_file = bundle_dir / TUMOR_MODEL_3D_CONFIG.get(
        "config_file", "configs/inference.yaml"
    )
    for required_path, description in (
        (python_path, "3B tümör modeli Python ortamı"),
        (bundle_dir, "3B tümör model paketi"),
        (config_file, "3B tümör modeli inference ayarı"),
        (bundle_dir / "models" / "model.pt", "3B tümör model ağırlığı"),
    ):
        if not required_path.exists():
            return None, f"{description} bulunamadı: {required_path}"

    work_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    datalist_path = work_dir / "input.json"
    datalist_path.write_text(
        json.dumps({"testing": [{"image": ct_path.name}]}, ensure_ascii=False),
        encoding="utf-8",
    )
    command = [
        str(python_path), "-m", "monai.bundle", "run",
        "--config_file", str(config_file),
        "--dataset_dir", str(ct_path.parent.resolve()),
        "--data_list_file_path", str(datalist_path.resolve()),
        "--output_dir", str(output_dir.resolve()),
        "--dataloader#num_workers", "0",
        "--inferer#sw_batch_size", str(TUMOR_MODEL_3D_CONFIG.get("sw_batch_size", 1)),
    ]
    timeout_seconds = int(TUMOR_MODEL_3D_CONFIG.get("timeout_seconds", 900))
    update_progress(
        job_id, 78, "3B tümör modeli çalışıyor",
        "DiNTS hacim boyunca pankreas ve tümör adaylarını tarıyor",
    )
    with open(log_path, "w", encoding="utf-8", errors="replace") as log_file:
        process = subprocess.run(
            command, cwd=str(bundle_dir), stdout=log_file,
            stderr=subprocess.STDOUT, text=True, timeout=timeout_seconds,
            env=os.environ.copy(),
        )
    if process.returncode != 0:
        details = "3B tümör modeli hata ayrıntısı üretemedi."
        if log_path.exists():
            details = log_path.read_text(encoding="utf-8", errors="replace")[-2500:].strip()
        return None, f"3B tümör modeli başarısız oldu: {details}"

    mask_files = sorted(output_dir.rglob("*_trans.nii.gz"))
    if len(mask_files) != 1:
        return None, f"3B tümör modeli tek maske üretmedi (bulunan: {len(mask_files)})."
    return mask_files[0], None


def _run_anatomical_gate(
    ct_path: Path, output_dir: Path, log_path: Path, job_id: str = ""
):
    """TotalSegmentator ile bağımsız, tam çözünürlüklü 3B pankreas kapısı üretir."""
    if not _parse_bool(ANATOMICAL_GATE_CONFIG.get("enabled"), True):
        return None, "3B anatomik doğrulama yapılandırmada kapalı; ham maske yayınlanmadı."

    executable = Path(ANATOMICAL_GATE_CONFIG.get(
        "executable", ".venv_totalseg/Scripts/TotalSegmentator.exe"
    ))
    if not executable.is_absolute():
        executable = BASE_PATH / executable
    if not executable.exists():
        return None, f"3B anatomik model çalıştırıcısı bulunamadı: {executable}"

    home_dir = Path(ANATOMICAL_GATE_CONFIG.get("home_dir", "data/totalsegmentator"))
    if not home_dir.is_absolute():
        home_dir = BASE_PATH / home_dir
    home_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)

    command = [
        str(executable), "-i", str(ct_path), "-o", str(output_dir),
        "--roi_subset", "pancreas",
        "--device", str(ANATOMICAL_GATE_CONFIG.get("device", "gpu")),
        "--nr_thr_saving", "1",
    ]
    if _parse_bool(ANATOMICAL_GATE_CONFIG.get("fast"), False):
        command.append("--fast")

    environment = os.environ.copy()
    environment["TOTALSEG_HOME_DIR"] = str(home_dir)
    timeout_seconds = int(ANATOMICAL_GATE_CONFIG.get("timeout_seconds", 900))
    update_progress(
        job_id, 73, "3B anatomik doğrulama",
        "Bağımsız model pankreas konumunu tam çözünürlükte kontrol ediyor",
    )
    with open(log_path, "w", encoding="utf-8", errors="replace") as log_file:
        process = subprocess.run(
            command, stdout=log_file, stderr=subprocess.STDOUT, text=True,
            timeout=timeout_seconds, env=environment,
        )
    if process.returncode != 0:
        details = "3B anatomik model hata ayrıntısı üretemedi."
        if log_path.exists():
            details = log_path.read_text(encoding="utf-8", errors="replace")[-2000:].strip()
        return None, f"3B anatomik doğrulama başarısız oldu: {details}"

    pancreas_path = output_dir / "pancreas.nii.gz"
    if not pancreas_path.exists():
        return None, "3B anatomik model pankreas maskesi üretmedi."
    return pancreas_path, None


def _run_inference(
    ct_path: Path, case_id: str, job_id: str = "", checkpoint_name: str = None
) -> tuple["Optional[np.ndarray]", "Optional[str]", dict]:
    """nnU-Net çıktısını bağımsız 3B anatomik kapıyla doğrular."""
    import numpy as np
    import nibabel as nib

    results_dir = Path(os.environ.get(
        "nnUNet_results", str(BASE_PATH / "data" / "nnunet_results")
    ))
    fold_dir = (
        results_dir / "Dataset007_Pancreas" /
        "nnUNetTrainer__nnUNetPlans__2d" / "fold_0"
    )
    selected_checkpoint = checkpoint_name or MODEL_CHECKPOINT
    if selected_checkpoint not in {"checkpoint_final.pth", "checkpoint_best.pth"}:
        return None, f"Geçersiz model checkpoint adı: {selected_checkpoint}", {}
    if not (fold_dir / selected_checkpoint).exists():
        return None, f"Eğitilmiş nnU-Net checkpoint bulunamadı: {fold_dir / selected_checkpoint}", {}

    safe_case = secure_filename(case_id) or "case"
    run_id = uuid.uuid4().hex[:8]
    tmp_input = UPLOAD_DIR / f"tmp_input_{safe_case}_{run_id}"
    tmp_output = UPLOAD_DIR / f"tmp_output_{safe_case}_{run_id}"
    log_path = UPLOAD_DIR / f"tmp_model_{safe_case}_{run_id}.log"
    dints_work = UPLOAD_DIR / f"tmp_dints_work_{safe_case}_{run_id}"
    dints_output = UPLOAD_DIR / f"tmp_dints_output_{safe_case}_{run_id}"
    dints_log_path = UPLOAD_DIR / f"tmp_dints_{safe_case}_{run_id}.log"
    gate_output = UPLOAD_DIR / f"tmp_gate_{safe_case}_{run_id}"
    gate_log_path = UPLOAD_DIR / f"tmp_gate_{safe_case}_{run_id}.log"
    tmp_input.mkdir(parents=True, exist_ok=False)
    tmp_output.mkdir(parents=True, exist_ok=False)
    try:
        in_file_path = tmp_input / f"{safe_case}_0000.nii.gz"
        if ct_path.name.lower().endswith(".nii.gz"):
            try:
                os.link(ct_path, in_file_path)
            except OSError:
                shutil.copy2(str(ct_path), str(in_file_path))
        else:
            import gzip
            with open(ct_path, "rb") as source:
                with gzip.open(in_file_path, "wb", compresslevel=6) as destination:
                    shutil.copyfileobj(source, destination)

        command = [
            sys.executable, "-c",
            "from nnunetv2.inference.predict_from_raw_data import predict_entry_point; predict_entry_point()",
            "-i", str(tmp_input), "-o", str(tmp_output),
            "-d", "007", "-c", "2d", "-f", "0",
            "-step_size", "0.5", "-npp", "1", "-nps", "1",
            "-chk", selected_checkpoint,
        ]
        update_progress(job_id, 65, "Model çalışıyor", "nnU-Net pankreas ve tümör maskesini çıkarıyor")
        debug_log(
            "MODEL", "Inference başladı; giriş=%s, checkpoint=%s",
            ct_path.name, selected_checkpoint,
        )
        with open(log_path, "w", encoding="utf-8", errors="replace") as log_file:
            process = subprocess.run(
                command,
                stdout=log_file,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=MODEL_TIMEOUT_SECONDS,
                env=os.environ.copy(),
            )

        if process.returncode != 0:
            details = "nnU-Net hata ayrıntısı alınamadı."
            if log_path.exists():
                details = log_path.read_text(encoding="utf-8", errors="replace")[-2000:].strip()
            return None, f"Model inference başarısız oldu: {details}", {}

        mask_files = sorted(tmp_output.glob("*.nii.gz"))
        if not mask_files:
            return None, "Model çalıştı fakat segmentasyon maskesi üretmedi.", {}

        update_progress(job_id, 70, "nnU-Net tamamlandı", "Ham 2B segmentasyon maskesi yükleniyor")
        mask_img = nib.load(str(mask_files[0]))
        raw_mask = np.asanyarray(mask_img.dataobj).astype(np.uint8, copy=False)

        gate_path, gate_error = _run_anatomical_gate(
            in_file_path, gate_output, gate_log_path, job_id=job_id
        )
        if gate_path is None:
            return None, gate_error, {}
        gate_img = nib.load(str(gate_path))
        gate_data = np.asanyarray(gate_img.dataobj)
        if raw_mask.shape != gate_data.shape:
            return None, (
                "3B anatomik kapı ile nnU-Net maskesinin boyutları uyuşmuyor: "
                f"{raw_mask.shape} / {gate_data.shape}"
            ), {}
        if not np.allclose(mask_img.affine, gate_img.affine, atol=1e-3, rtol=1e-5):
            return None, "3B anatomik maske ile nnU-Net dünya koordinatları uyuşmuyor.", {}

        from segmentation_postprocess import validate_and_fuse_segmentation
        spacing = nib.affines.voxel_sizes(mask_img.affine)
        _, nnunet_tumor_voxels = _count_mask_labels(raw_mask)

        # Pankreas kapısı fiziksel olarak geçersizse pahalı tümör modelini hiç
        # çalıştırma ve ham nnU-Net maskesini yayınlamadan kapalı kal.
        mask_data, quality = validate_and_fuse_segmentation(
            raw_mask, gate_data, spacing, ANATOMICAL_GATE_CONFIG
        )
        if quality.get("gate_plausible"):
            dints_path, dints_error = _run_dints_tumor_model(
                in_file_path, dints_work, dints_output, dints_log_path, job_id=job_id
            )
            if dints_path is None:
                return None, dints_error, {}
            dints_img = nib.load(str(dints_path))
            dints_mask = np.asanyarray(dints_img.dataobj).astype(np.uint8, copy=False)
            if raw_mask.shape != dints_mask.shape:
                return None, (
                    "2B nnU-Net ile 3B DiNTS maskelerinin boyutları uyuşmuyor: "
                    f"{raw_mask.shape} / {dints_mask.shape}"
                ), {}
            if not np.allclose(mask_img.affine, dints_img.affine, atol=1e-3, rtol=1e-5):
                return None, "2B nnU-Net ile 3B DiNTS dünya koordinatları uyuşmuyor.", {}

            # Duyarlılık odaklı birleşim, bağımsız kapı ve fiziksel bileşen
            # kurallarıyla yalancı pozitiflerden arındırılır.
            ensemble_mask = np.maximum(raw_mask, dints_mask)
            mask_data, quality = validate_and_fuse_segmentation(
                ensemble_mask, gate_data, spacing, ANATOMICAL_GATE_CONFIG
            )
            _, dints_tumor_voxels = _count_mask_labels(dints_mask)
        else:
            dints_tumor_voxels = 0
            quality["dints_skipped_reason"] = "3B pankreas kapısı fiziksel olarak geçersiz."

        quality["nnunet_raw_tumor_voxels"] = nnunet_tumor_voxels
        quality["dints_raw_tumor_voxels"] = dints_tumor_voxels
        quality["models"] = (
            ["nnU-Net v2 2D", "MONAI DiNTS 3B", "TotalSegmentator 3B full"]
            if quality.get("gate_plausible")
            else ["nnU-Net v2 2D", "TotalSegmentator 3B full"]
        )
        quality["checkpoint"] = selected_checkpoint
        update_progress(job_id, 89, "3B doğrulama tamamlandı", "Fiziksel bileşen ölçütleri uygulandı")

        persistent_mask = nib.Nifti1Image(mask_data, mask_img.affine, mask_img.header)
        persistent_mask.set_data_dtype(np.uint8)
        persistent_mask.set_qform(mask_img.affine, code=1)
        persistent_mask.set_sform(mask_img.affine, code=1)
        nib.save(persistent_mask, str(MASK_DIR / f"{safe_case}.nii.gz"))
        debug_log(
            "MODEL", "Inference tamamlandı; maske=%s, 3B kalite=%s",
            mask_data.shape, quality,
        )
        return mask_data, None, quality
    except subprocess.TimeoutExpired:
        return None, "Model zinciri zaman sınırını aştı.", {}
    except Exception as exc:
        return None, f"Inference sırasında hata oluştu: {exc}", {}
    finally:
        shutil.rmtree(tmp_input, ignore_errors=True)
        shutil.rmtree(tmp_output, ignore_errors=True)
        shutil.rmtree(dints_work, ignore_errors=True)
        shutil.rmtree(dints_output, ignore_errors=True)
        shutil.rmtree(gate_output, ignore_errors=True)
        log_path.unlink(missing_ok=True)
        dints_log_path.unlink(missing_ok=True)
        gate_log_path.unlink(missing_ok=True)
        gc.collect()


def _create_web_viz(ct_data, mask_data, result, output_path: Path):
    """Pankreas içeren tam 8 kesitte CT + değişmeden gelen model maskesini gösterir."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    from matplotlib.colors import ListedColormap
    import numpy as np

    try:
        ct_view = np.squeeze(ct_data)
        mask_view = np.squeeze(mask_data)
        if ct_view.ndim == 2:
            ct_view = ct_view[:, :, np.newaxis]
        if mask_view.ndim == 2:
            mask_view = mask_view[:, :, np.newaxis]
        if ct_view.ndim > 3:
            ct_view = ct_view[..., 0]
        if mask_view.ndim > 3:
            mask_view = mask_view[..., 0]
        if ct_view.ndim != 3 or mask_view.ndim != 3:
            raise ValueError("CT veya maske üç boyutlu değil.")

        if ct_view.shape != mask_view.shape:
            for axes in ((1, 2, 0), (2, 0, 1), (0, 2, 1), (2, 1, 0)):
                candidate = np.transpose(ct_view, axes)
                if candidate.shape == mask_view.shape:
                    ct_view = candidate
                    break
        if ct_view.shape != mask_view.shape:
            raise ValueError(f"CT ve maske boyutları uyuşmuyor: {ct_view.shape} / {mask_view.shape}")

        depth = mask_view.shape[2]
        pan_counts = np.zeros(depth, dtype=np.int64)
        tum_counts = np.zeros(depth, dtype=np.int64)
        for slice_index in range(depth):
            slice_mask = mask_view[:, :, slice_index]
            pan_counts[slice_index] = np.count_nonzero(slice_mask == 1)
            tum_counts[slice_index] = np.count_nonzero(slice_mask == 2)

        pancreas_indices = np.flatnonzero(pan_counts > 0)
        selected = []
        if pancreas_indices.size:
            tumor_indices = pancreas_indices[tum_counts[pancreas_indices] > 0]
            if tumor_indices.size:
                ranked_tumor = tumor_indices[np.argsort(-tum_counts[tumor_indices])]
                selected.extend(int(value) for value in ranked_tumor[:4])

            distributed_positions = np.linspace(
                0, pancreas_indices.size - 1, min(8, pancreas_indices.size), dtype=int
            )
            selected.extend(int(pancreas_indices[position]) for position in distributed_positions)
            selected = list(dict.fromkeys(selected))[:8]
            while len(selected) < 8:
                selected.append(int(pancreas_indices[len(selected) % pancreas_indices.size]))
        else:
            selected = [int(value) for value in np.linspace(0, max(0, depth - 1), 8, dtype=int)]

        result["visualized_slices"] = selected
        result["visualized_pancreas_slices"] = int(sum(pan_counts[index] > 0 for index in selected))
        figure, axes = plt.subplots(
            2, 4, figsize=(20, 10), facecolor="#0d0d1a", squeeze=False
        )
        mask_cmap = ListedColormap(["none", "#27ae60", "#e74c3c"])

        for panel, slice_index in enumerate(selected):
            axis = axes.flat[panel]
            ct_slice = np.asarray(ct_view[:, :, slice_index], dtype=np.float32).T
            ct_slice = np.nan_to_num(ct_slice, nan=-150.0, posinf=250.0, neginf=-150.0)
            ct_slice = np.clip(ct_slice, -150.0, 250.0)
            ct_slice = (ct_slice + 150.0) / 400.0
            mask_slice = np.asarray(mask_view[:, :, slice_index]).T

            axis.imshow(ct_slice, cmap="gray", origin="lower", vmin=0, vmax=1)
            axis.imshow(
                np.ma.masked_where(mask_slice < 0.5, mask_slice),
                cmap=mask_cmap, alpha=0.62, origin="lower", vmin=0, vmax=2,
            )
            tumor_text = f" • Tümör {int(tum_counts[slice_index])}" if tum_counts[slice_index] else ""
            axis.set_title(
                f"Kesit {slice_index} • Pankreas {int(pan_counts[slice_index])}{tumor_text}",
                color="white", fontsize=10, fontweight="bold",
            )
            axis.axis("off")

        if result.get("has_tumor") is True:
            color = "#e74c3c"
        elif result.get("has_tumor") is False and result.get("pancreas_verified"):
            color = "#2ecc71"
        else:
            color = "#f59e0b"
        figure.suptitle(
            f"SONUÇ: {result.get('prediction', '?')}",
            fontsize=20, fontweight="bold", color=color, y=1.01,
        )
        figure.legend(
            handles=[
                mpatches.Patch(color="#27ae60", label="Pankreas (Label 1)"),
                mpatches.Patch(color="#e74c3c", label="Tümör (Label 2)"),
            ],
            loc="lower center", ncol=2, facecolor="#1a1a2e",
            labelcolor="white", fontsize=12,
        )
        figure.tight_layout(rect=(0, 0.05, 1, 0.97))
        output_path.parent.mkdir(parents=True, exist_ok=True)
        figure.savefig(
            str(output_path), dpi=170, bbox_inches="tight", facecolor="#0d0d1a"
        )
        plt.close(figure)
        debug_log("GÖRSEL", "8 panel hazırlandı; kesitler=%s", selected)
    except Exception as exc:
        plt.close("all")
        debug_log("GÖRSEL", "Görselleştirme hatası: %s", exc)
        raise


# ============================================================
# MAIN
# ============================================================
def run_startup_checks():
    """Başlangıç ayarlarını doğrular; ayrıntıları yalnız DEBUG=True iken yazar."""
    port = int(os.environ.get("FLASK_PORT", WEB_CONFIG.get("port", 5000)))
    checkpoint_dir = (
        Path(os.environ.get("nnUNet_results", BASE_PATH / "data" / "nnunet_results")) /
        "Dataset007_Pancreas" / "nnUNetTrainer__nnUNetPlans__2d" / "fold_0"
    )
    checkpoint_ok = any((checkpoint_dir / name).exists() for name in (
        "checkpoint_final.pth", "checkpoint_best.pth"
    ))
    debug_log("BAŞLANGIÇ", "DEBUG=%s", DEBUG_ENABLED)
    debug_log(
        "BAŞLANGIÇ", "Port=%s, yükleme=%s MB, dosya sınırı=%s",
        port, MAX_UPLOAD_MB, MAX_UPLOAD_FILES,
    )
    debug_log("BAŞLANGIÇ", "Model checkpoint=%s", "hazır" if checkpoint_ok else "bulunamadı")
    try:
        import psutil
        memory_gb = psutil.virtual_memory().total / (1024 ** 3)
        debug_log("BAŞLANGIÇ", "Sistem RAM=%.1f GB; disk tabanlı yükleme etkin", memory_gb)
    except Exception:
        debug_log("BAŞLANGIÇ", "RAM bilgisi okunamadı; disk tabanlı yükleme etkin")
    return port


if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=run_startup_checks(),
        debug=DEBUG_ENABLED,
        threaded=True,
        use_reloader=False,
    )
