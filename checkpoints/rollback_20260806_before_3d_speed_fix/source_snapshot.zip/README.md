# PancreasCancerDetection

CT görüntülerinde pankreas ve tümör adayı segmentasyonu — nnU-Net 2D + DiNTS 3D ensemble ve bağımsız TotalSegmentator 3D anatomik doğrulama.

## Proje Yapısı

```
PancreasCancer/
├── data/
│   ├── raw/                         # Kaggle'dan indirilen orijinal NIfTI dosyaları
│   ├── nnunet_raw/                  # nnU-Net formatına çevrilmiş veriler
│   │   └── Dataset007_Pancreas/
│   │       ├── imagesTr/            # Eğitim CT'leri (case_XXXX_0000.nii.gz)
│   │       ├── labelsTr/            # Eğitim maskeleri (case_XXXX.nii.gz)
│   │       ├── imagesTs/            # Test CT'leri
│   │       └── dataset.json
│   ├── nnunet_preprocessed/         # nnU-Net ön işleme (otomatik)
│   ├── nnunet_results/              # Eğitilmiş model ağırlıkları
│   └── inference_output/            # Segmentasyon sonuçları
├── scripts/
│   ├── utils.py                     # Ortak yardımcı fonksiyonlar
│   ├── prepare_dataset.py           # ADIM 2: Veri hazırlama
│   ├── validate_metrics.py          # ADIM 5: Doğrulama metrikleri
│   ├── inference.py                 # ADIM 6-7: Inference + Classification
│   ├── segmentation_postprocess.py  # 3B anatomik kapı ve fiziksel bileşen filtresi
│   ├── audit_tumor_ensemble.py      # Ensemble doğrulama denetimi
│   └── reconstruct_3d.py            # ADIM 8: 3D Rekonstrüksiyon
├── web/
│   ├── app.py                       # Flask web uygulaması
│   ├── templates/
│   └── static/
├── logs/
├── metrics/
├── notebooks/
├── setup_project.py                 # ADIM 1: Proje kurulumu
├── verify_step1.py                  # ADIM 1: Kurulum doğrulama
├── requirements.txt
├── requirements-3d.txt              # Ayrı 3B model ortamı
├── setup.bat                        # Windows kurulum
├── setup.sh                         # Linux/Mac kurulum
└── config.json                      # Merkezi konfigürasyon
```

## Hızlı Başlangıç

### 1. Kurulum (Windows)
```batch
setup.bat
```

### 2. Sanal Ortamı Aktif Et
```powershell
.\venv\Scripts\activate
```

### 3. nnU-Net Ortam Değişkenleri (PowerShell)
```powershell
$env:nnUNet_raw          = "C:\...\data\nnunet_raw"
$env:nnUNet_preprocessed = "C:\...\data\nnunet_preprocessed"
$env:nnUNet_results      = "C:\...\data\nnunet_results"
```

### 4. Veriyi İndir
Kaggle'dan [MSD Task07 Pancreas](https://www.kaggle.com/datasets/andrewmvd/medical-segmentation-decathlon) veri setini `data/raw/` klasörüne indirin.

### 5. Adımları Çalıştır
```bash
python scripts/prepare_dataset.py        # ADIM 2
nnUNetv2_plan_and_preprocess -d 007 -c 2d  # ADIM 3
nnUNetv2_train 007 2d 0                  # ADIM 4
python scripts/validate_metrics.py       # ADIM 5
python scripts/inference.py              # ADIM 6-7
python web/app.py                        # ADIM 9
```

## Etiketler

| Değer | Anlamı |
|-------|--------|
| 0 | Arka plan (Background) |
| 1 | Pankreas |
| 2 | Tümör |

## Metrikler

**Segmentasyon:** Dice Score, IoU
**Sınıflandırma:** Accuracy, Precision, Recall, F1, ROC-AUC

## Üretim karar mantığı

- DICOM yüklemesinde portal-venöz abdomen serisi seçilir; toraks/boyun reddedilir.
- Hasta geometrisi IOP/IPP/PixelSpacing ile NIfTI affine'e taşınır.
- nnU-Net 2D ve MONAI DiNTS 3D adayları birleştirilir.
- TotalSegmentator 3D full pankreası bağımsız olarak doğrular.
- Tümör bileşeni en az 0,30 mL, en az 2 kesit ve pankreasın 30 mm anatomik bandında olmalıdır.
- Anatomik doğrulama başarısızsa ham maske gösterilmez ve karar verilmez.

Ayrıntılı ölçüm ve değişiklikler: [SEGMENTASYON_DUZELTME_RAPORU.md](SEGMENTASYON_DUZELTME_RAPORU.md)

## Notlar

- GPU belleği 8GB altındaysa `--batch_size 2` kullanın
- Sadece fold 0 ile eğitim yapılmaktadır
- 3B modeller ayrı `.venv_totalseg` ortamında çalışır; CUDA uyumlu PyTorch gerekir.
- Web analizi hacme göre yaklaşık 4–8 dakika sürebilir.
- Araştırma amaçlıdır; klinik tanı aracı değildir.
