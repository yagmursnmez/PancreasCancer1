"""3B anatomik kapı ile pankreas/tümör maskesi doğrulama.

Bu modül model olasılığı uydurmaz. İki bağımsız segmentasyonun anatomik
uyumunu ölçer; pankreas güvenilir biçimde doğrulanamazsa tümör kararı vermek
yerine ``indeterminate`` döndürür.
"""

from __future__ import annotations

from typing import Any, Mapping, Sequence

import numpy as np
from scipy import ndimage


DEFAULTS = {
    "min_pancreas_ml": 3.0,
    "max_pancreas_ml": 250.0,
    "min_pancreas_slices": 3,
    "min_cross_model_dice": 0.20,
    "pancreas_fusion_radius_mm": 30.0,
    "tumor_support_radius_mm": 30.0,
    "min_tumor_component_ml": 0.30,
    "min_tumor_slices": 2,
    "min_tumor_support_fraction": 0.01,
}


def _settings(overrides: Mapping[str, Any] | None) -> dict[str, Any]:
    values = dict(DEFAULTS)
    if overrides:
        values.update(overrides)
    return values


def _voxel_volume_ml(spacing: Sequence[float]) -> float:
    values = np.asarray(spacing[:3], dtype=float)
    if values.shape != (3,) or not np.all(np.isfinite(values)) or np.any(values <= 0):
        raise ValueError(f"Geçersiz voksel aralığı: {spacing}")
    return float(np.prod(values) / 1000.0)


def _slice_count(binary: np.ndarray) -> int:
    axes = tuple(range(binary.ndim - 1))
    return int(np.count_nonzero(np.any(binary, axis=axes)))


def _largest_component(binary: np.ndarray) -> tuple[np.ndarray, int, int]:
    """En büyük 26-bağlantılı bileşeni bellek dostu kırpılmış alanda tutar."""
    binary = np.asarray(binary, dtype=bool)
    output = np.zeros(binary.shape, dtype=bool)
    points = np.where(binary)
    if not points[0].size:
        return output, 0, 0

    bounds = tuple(slice(int(axis.min()), int(axis.max()) + 1) for axis in points)
    crop = binary[bounds]
    labels, count = ndimage.label(
        crop,
        structure=ndimage.generate_binary_structure(3, 3),
    )
    if count == 1:
        output[bounds] = crop
        return output, 1, int(np.count_nonzero(crop))

    sizes = np.bincount(labels.ravel())
    sizes[0] = 0
    largest_id = int(np.argmax(sizes))
    output[bounds] = labels == largest_id
    return output, int(count), int(sizes[largest_id])


def _dilate_mm(binary: np.ndarray, radius_mm: float, spacing: Sequence[float]) -> np.ndarray:
    """Fiziksel Öklid uzaklığıyla genişlet; yalnızca organ çevresindeki kutuyu işler."""
    binary = np.asarray(binary, dtype=bool)
    output = np.zeros(binary.shape, dtype=bool)
    points = np.where(binary)
    if not points[0].size:
        return output
    if radius_mm <= 0:
        output[...] = binary
        return output

    spacing_arr = np.asarray(spacing[:3], dtype=float)
    padding = np.ceil(radius_mm / spacing_arr).astype(int)
    bounds = tuple(
        slice(
            max(0, int(axis.min()) - int(padding[index])),
            min(binary.shape[index], int(axis.max()) + int(padding[index]) + 1),
        )
        for index, axis in enumerate(points)
    )
    crop = binary[bounds]
    distances = ndimage.distance_transform_edt(~crop, sampling=spacing_arr)
    output[bounds] = distances <= radius_mm
    return output


def _dice(left: np.ndarray, right: np.ndarray) -> float:
    left_count = int(np.count_nonzero(left))
    right_count = int(np.count_nonzero(right))
    if left_count + right_count == 0:
        return 1.0
    overlap = int(np.count_nonzero(left & right))
    return float(2.0 * overlap / (left_count + right_count))


def _component_records(
    tumor: np.ndarray,
    support: np.ndarray,
    voxel_ml: float,
    cfg: Mapping[str, Any],
) -> tuple[np.ndarray, list[dict[str, Any]]]:
    accepted = np.zeros(tumor.shape, dtype=bool)
    records: list[dict[str, Any]] = []
    points = np.where(tumor)
    if not points[0].size:
        return accepted, records

    bounds = tuple(slice(int(axis.min()), int(axis.max()) + 1) for axis in points)
    crop = tumor[bounds]
    labels, component_count = ndimage.label(
        crop,
        structure=ndimage.generate_binary_structure(3, 3),
    )
    support_crop = support[bounds]
    accepted_crop = np.zeros(crop.shape, dtype=bool)

    for component_id in range(1, int(component_count) + 1):
        component = labels == component_id
        voxel_count = int(np.count_nonzero(component))
        supported = component & support_crop
        supported_voxels = int(np.count_nonzero(supported))
        supported_ml = supported_voxels * voxel_ml
        supported_slices = _slice_count(supported)
        support_fraction = supported_voxels / max(1, voxel_count)

        reasons = []
        if supported_ml < float(cfg["min_tumor_component_ml"]):
            reasons.append("hacim_esigi")
        if supported_slices < int(cfg["min_tumor_slices"]):
            reasons.append("kesit_esigi")
        if support_fraction < float(cfg["min_tumor_support_fraction"]):
            reasons.append("pankreas_komsulugu")

        is_accepted = not reasons
        if is_accepted:
            # Bağımsız organ modelleri büyük tümörle deforme olmuş pankreası eksik
            # çizebilir. Bileşen anatomik banda tutunuyorsa, gerçek lezyonun dış
            # kısmını kesmemek için bileşenin tamamını koru.
            accepted_crop |= component

        records.append({
            "component": component_id,
            "raw_voxels": voxel_count,
            "raw_ml": round(voxel_count * voxel_ml, 4),
            "supported_voxels": supported_voxels,
            "supported_ml": round(supported_ml, 4),
            "supported_slices": supported_slices,
            "support_fraction": round(float(support_fraction), 4),
            "accepted": is_accepted,
            "rejection_reasons": reasons,
        })

    accepted[bounds] = accepted_crop
    return accepted, records


def validate_and_fuse_segmentation(
    raw_mask: np.ndarray,
    pancreas_gate: np.ndarray,
    spacing: Sequence[float],
    config: Mapping[str, Any] | None = None,
) -> tuple[np.ndarray, dict[str, Any]]:
    """nnU-Net maskesini bağımsız 3B pankreas maskesiyle doğrular ve birleştirir.

    Etiketler: 0 arka plan, 1 pankreas, 2 tümör. Kapı anatomik açıdan
    uygunsuzsa boş maske ve kararsız durum döner; ham tümör hiçbir zaman tek
    başına pozitif karar üretemez.
    """
    cfg = _settings(config)
    raw = np.squeeze(np.asarray(raw_mask))
    gate = np.squeeze(np.asarray(pancreas_gate)) > 0
    if raw.ndim != 3 or gate.ndim != 3:
        raise ValueError("Ham maske ve anatomik kapı üç boyutlu olmalıdır.")
    if raw.shape != gate.shape:
        raise ValueError(f"Maske boyutları uyuşmuyor: {raw.shape} / {gate.shape}")

    invalid_labels = sorted(set(np.unique(raw).tolist()) - {0, 1, 2})
    if invalid_labels:
        raise ValueError(f"Beklenmeyen segmentasyon etiketleri: {invalid_labels[:10]}")

    voxel_ml = _voxel_volume_ml(spacing)
    raw_organ = raw > 0
    raw_tumor = raw == 2
    gate_largest, gate_components, gate_voxels = _largest_component(gate)
    gate_ml = gate_voxels * voxel_ml
    gate_slices = _slice_count(gate_largest)

    qc: dict[str, Any] = {
        "status": "indeterminate",
        "pancreas_verified": False,
        "has_tumor": None,
        "voxel_volume_ml": round(voxel_ml, 7),
        "raw_pancreas_voxels": int(np.count_nonzero(raw == 1)),
        "raw_tumor_voxels": int(np.count_nonzero(raw_tumor)),
        "gate_voxels": gate_voxels,
        "gate_ml": round(gate_ml, 3),
        "gate_slices": gate_slices,
        "gate_components": gate_components,
        "gate_plausible": False,
        "tumor_components": [],
        "reason": None,
    }

    gate_plausible = (
        gate_voxels > 0
        and float(cfg["min_pancreas_ml"]) <= gate_ml <= float(cfg["max_pancreas_ml"])
        and gate_slices >= int(cfg["min_pancreas_slices"])
    )
    if not gate_plausible:
        qc["reason"] = "3B anatomik model pankreası güvenilir hacim ve kesit aralığında doğrulayamadı."
        qc["rejected_tumor_voxels"] = qc["raw_tumor_voxels"]
        return np.zeros(raw.shape, dtype=np.uint8), qc

    qc["gate_plausible"] = True

    agreement_dice = _dice(raw_organ, gate_largest)
    qc["cross_model_dice"] = round(agreement_dice, 4)

    fusion_support = _dilate_mm(
        gate_largest, float(cfg["pancreas_fusion_radius_mm"]), spacing
    )
    fused_organ = gate_largest | (raw_organ & fusion_support)
    fused_organ, _, _ = _largest_component(fused_organ)

    final = np.zeros(raw.shape, dtype=np.uint8)
    final[fused_organ] = 1

    if not np.any(raw_organ) or agreement_dice < float(cfg["min_cross_model_dice"]):
        qc["reason"] = "Bağımsız pankreas modelleri yeterli anatomik uyum göstermedi."
        qc["pancreas_voxels"] = int(np.count_nonzero(fused_organ))
        qc["pancreas_ml"] = round(int(np.count_nonzero(fused_organ)) * voxel_ml, 3)
        qc["tumor_voxels"] = 0
        qc["tumor_ml"] = 0.0
        qc["rejected_tumor_voxels"] = qc["raw_tumor_voxels"]
        return final, qc

    tumor_support = _dilate_mm(
        gate_largest, float(cfg["tumor_support_radius_mm"]), spacing
    )
    accepted_tumor, records = _component_records(
        raw_tumor, tumor_support, voxel_ml, cfg
    )
    final[accepted_tumor] = 2

    tumor_voxels = int(np.count_nonzero(accepted_tumor))
    pancreas_voxels = int(np.count_nonzero(final == 1))
    qc.update({
        "status": "verified",
        "pancreas_verified": True,
        "has_tumor": bool(tumor_voxels > 0),
        "pancreas_voxels": pancreas_voxels,
        "pancreas_ml": round(pancreas_voxels * voxel_ml, 3),
        "tumor_voxels": tumor_voxels,
        "tumor_ml": round(tumor_voxels * voxel_ml, 3),
        "rejected_tumor_voxels": int(np.count_nonzero(raw_tumor & ~accepted_tumor)),
        "tumor_components": records,
        "reason": None,
    })
    return final, qc
